# Tournament Deck Implementation

This wave keeps the checked-in tournament snapshots composition-exact while applying the repository's executable-behaviour gate. A source placement is provenance only; it is not a claim about simulated strength.

## Current gate

- 37 source-attributed snapshots are checked in (37 unique resolved compositions).
- All 37 manifests resolve to exactly 60 cards with zero unresolved printing copies.
- 0 source snapshots are currently simulation-ready. This is intentional: each blocked list exposes its exact missing behaviour families in Deck Library and `META_DECK_CORPUS.md`.
- The existing Skeledirge ex, Okidogi ex Poison, Team Rocket's Nidoking ex, Arcanine and Gengar Wave 1 decks remain the regression baseline.

## Priority implementation backlog

`npm run decks:coverage-plan` ranks missing families by blocked source decks, best placement and blocked copies. The highest-value work is the shared Dragapult/Dreepy line, Crispin and Area Zero, Meowth ex, Fezandipiti ex, Dusknoir line, and the tournament Trainer/ACE SPEC families. No effect is approximated to make a source deck appear ready.

## Verification

Run `npm run acceptance:meta-decks` after changing card behaviour. It validates mandatory source IDs, exact 60-card manifests, printing resolution accounting and the simulation-ready invariant. Runtime gauntlets should only be run for decks that clear that gate; the acceptance command reports blocked decks and their explicit blockers instead of silently substituting cards.

## Next wave

Implement the shared families in the coverage plan first, then re-run corpus resolution and promote a deck only after its complete 60-card runtime batch passes against Skeledirge, Okidogi and Team Rocket baselines plus a mirror batch.
