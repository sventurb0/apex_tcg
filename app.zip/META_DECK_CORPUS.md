# Meta Deck Corpus

Generated 2026-07-23T20:54:56.177Z. These are composition-exact public snapshots. A canonical-equivalent printing is used only when gameplay identity is verified; it is not represented as the player's cosmetic printing. Tournament placement is provenance, not evidence of simulated strength.

## Summary

- Source snapshots: 37
- Unique resolved compositions: 37
- Events: 3 (NAIC 2026, New Orleans, Special Event Turin, Special Event Turin (SR))
- Archetypes: 16
- Simulation-ready source decks: 0
- Exact source printing copies resolved: 1927
- Canonical-equivalent copies resolved: 293
- Unresolved copies: 0

## Sources and status

| Archetype | Player | Event | Place | Exact | Canonical | Unresolved | Simulation | Attribution |
|---|---|---|---:|---:|---:|---:|---|---|
| Lillie's Clefairy | James Kowalski | NAIC 2026, New Orleans | 1 | 51 | 9 | 0 | 16 blockers | [source](https://limitlesstcg.com/decks/list/28249) |
| Dragapult Dusknoir | Neddy Kosek | Special Event Turin (SR) | 2 | 52 | 8 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28236) |
| Dragapult | Justin Newdorf | NAIC 2026, New Orleans | 3 | 51 | 9 | 0 | 12 blockers | [source](https://limitlesstcg.com/decks/list/28250) |
| Slowking | Ross Cawthon | NAIC 2026, New Orleans | 4 | 56 | 4 | 0 | 17 blockers | [source](https://limitlesstcg.com/decks/list/28251) |
| Crustle | Rahul Reddy | NAIC 2026, New Orleans | 5 | 59 | 1 | 0 | 17 blockers | [source](https://limitlesstcg.com/decks/list/28252) |
| Rocket's Mewtwo | Juho Kallama | NAIC 2026, New Orleans | 7 | 53 | 7 | 0 | 9 blockers | [source](https://limitlesstcg.com/decks/list/28254) |
| N's Zoroark | Tord Reklev | NAIC 2026, New Orleans | 10 | 53 | 7 | 0 | 13 blockers | [source](https://limitlesstcg.com/decks/list/28257) |
| Ogerpon Box | Mees Brenninkmeijer | NAIC 2026, New Orleans | 18 | 49 | 11 | 0 | 17 blockers | [source](https://limitlesstcg.com/decks/list/28262) |
| Hydrapple | Grant Walworth | NAIC 2026, New Orleans | 25 | 46 | 14 | 0 | 18 blockers | [source](https://limitlesstcg.com/decks/list/28266) |
| Alakazam Dudunsparce | Cerys Jones | NAIC 2026, New Orleans | 227 | 59 | 1 | 0 | 22 blockers | [source](https://limitlesstcg.com/decks/list/28405) |
| Dragapult Blaziken | Jon Webb | NAIC 2026, New Orleans | 6 | 52 | 8 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28253) |
| Dragapult | Miguel Angel Marin Herrera | NAIC 2026, New Orleans | 8 | 52 | 8 | 0 | 13 blockers | [source](https://limitlesstcg.com/decks/list/28255) |
| Dragapult | Abaan Ahmed | NAIC 2026, New Orleans | 9 | 51 | 9 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28256) |
| Dragapult Blaziken | Jackson Ford | NAIC 2026, New Orleans | 12 | 52 | 8 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28258) |
| Dragapult Dusknoir | Natalie Millar | NAIC 2026, New Orleans | 13 | 52 | 8 | 0 | 11 blockers | [source](https://limitlesstcg.com/decks/list/28259) |
| N's Zoroark | Liam Halliburton | NAIC 2026, New Orleans | 14 | 52 | 8 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28260) |
| Dragapult | Leonardo Lattanzi | NAIC 2026, New Orleans | 16 | 51 | 9 | 0 | 10 blockers | [source](https://limitlesstcg.com/decks/list/28261) |
| Ogerpon Box | Nicholas Cucinelli | NAIC 2026, New Orleans | 20 | 45 | 15 | 0 | 14 blockers | [source](https://limitlesstcg.com/decks/list/28263) |
| Dragapult | Paolo Camus | NAIC 2026, New Orleans | 22 | 51 | 9 | 0 | 10 blockers | [source](https://limitlesstcg.com/decks/list/28264) |
| Slowking | Isaac Alexander Martinez Mendoza | NAIC 2026, New Orleans | 24 | 57 | 3 | 0 | 21 blockers | [source](https://limitlesstcg.com/decks/list/28265) |
| Crustle | Hale Obernolte | NAIC 2026, New Orleans | 26 | 59 | 1 | 0 | 16 blockers | [source](https://limitlesstcg.com/decks/list/28267) |
| Dragapult | Daniel Powell | NAIC 2026, New Orleans | 27 | 51 | 9 | 0 | 11 blockers | [source](https://limitlesstcg.com/decks/list/28268) |
| Hydrapple | Ben Dobberstein | NAIC 2026, New Orleans | 28 | 47 | 13 | 0 | 16 blockers | [source](https://limitlesstcg.com/decks/list/28269) |
| N's Zoroark | Luke Morsa | NAIC 2026, New Orleans | 29 | 52 | 8 | 0 | 11 blockers | [source](https://limitlesstcg.com/decks/list/28270) |
| Dragapult | Jack Moore | NAIC 2026, New Orleans | 31 | 51 | 9 | 0 | 9 blockers | [source](https://limitlesstcg.com/decks/list/28271) |
| Dragapult | Caleb Gedemer | NAIC 2026, New Orleans | 32 | 51 | 9 | 0 | 11 blockers | [source](https://limitlesstcg.com/decks/list/28272) |
| Dragapult | Blake Underhill | NAIC 2026, New Orleans | 33 | 51 | 9 | 0 | 11 blockers | [source](https://limitlesstcg.com/decks/list/28273) |
| N's Zoroark | Benjamin Martinsen | NAIC 2026, New Orleans | 35 | 52 | 8 | 0 | 10 blockers | [source](https://limitlesstcg.com/decks/list/28274) |
| Alakazam Dudunsparce | Diego Cassiraga | NAIC 2026, New Orleans | 36 | 59 | 1 | 0 | 20 blockers | [source](https://limitlesstcg.com/decks/list/28275) |
| Crustle | Christopher Carillon | NAIC 2026, New Orleans | 37 | 57 | 3 | 0 | 16 blockers | [source](https://limitlesstcg.com/decks/list/28276) |
| Mega Lucario | Nicolai Stiborg | Special Event Turin | 45 | 52 | 8 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/27961) |
| Metagross | Drew Cate | NAIC 2026, New Orleans | 252 | 43 | 17 | 0 | 15 blockers | [source](https://limitlesstcg.com/decks/list/28423) |
| Mega Greninja | Darien Krys | NAIC 2026, New Orleans | 471 | 53 | 7 | 0 | 16 blockers | [source](https://limitlesstcg.com/decks/list/28571) |
| Joltik Box | Angel Daniel Cardenas Eduardo | NAIC 2026, New Orleans | 638 | 46 | 14 | 0 | 18 blockers | [source](https://limitlesstcg.com/decks/list/28692) |
| Festival Lead | Leighton Catton | NAIC 2026, New Orleans | 164 | 55 | 5 | 0 | 20 blockers | [source](https://limitlesstcg.com/decks/list/28371) |
| Lillie's Clefairy | Zachary Davis | NAIC 2026, New Orleans | 619 | 51 | 9 | 0 | 17 blockers | [source](https://limitlesstcg.com/decks/list/28675) |
| Rocket's Mewtwo | Jacob Peltier | NAIC 2026, New Orleans | 135 | 53 | 7 | 0 | 7 blockers | [source](https://limitlesstcg.com/decks/list/28351) |

## Exact blockers

### Lillie's Clefairy — James Kowalski

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 4× Meowth ex (me3-62): unsupported; no executable behaviour family
- 4× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 3× Latias ex (sv8-76): unsupported; no executable behaviour family
- 2× Wellspring Mask Ogerpon ex (sv6-64): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Chien-Pao (sv8-56): unsupported; no executable behaviour family
- 1× Koraidon ex (me2pt5-121): unsupported; no executable behaviour family
- 4× Crispin (sv7-133): unsupported; no executable behaviour family
- 2× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 4× Dusk Ball (sv8-175): unsupported; no executable behaviour family
- 3× Wondrous Patch (me2-94): unsupported; no executable behaviour family
- 1× Prime Catcher (sv5-157): unsupported; no executable behaviour family
- 2× Lillie's Pearl (sv9-151): unsupported; no executable behaviour family
- 4× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family
- 1× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family

### Dragapult Dusknoir — Neddy Kosek

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 2× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 2× Duskull (sv8pt5-35): unsupported; no executable behaviour family
- 2× Dusclops (sv8pt5-36): partial; no executable behaviour family
- 1× Dusknoir (sv8pt5-37): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family
- 1× Jamming Tower (sv6-153): unsupported; no executable behaviour family

### Dragapult — Justin Newdorf

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Dunsparce (sv9-120): unsupported; no executable behaviour family
- 1× Dudunsparce (sv5-129): partial; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 2× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Rosa's Encouragement (me3-84): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 2× Risky Ruins (me1-127): unsupported; no executable behaviour family

### Slowking — Ross Cawthon

- 4× Slowpoke (sv7-57): unsupported; no executable behaviour family
- 3× Slowking (sv7-58): unsupported; no executable behaviour family
- 3× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 2× Latias ex (sv8-76): unsupported; no executable behaviour family
- 2× Kyurem (sv6pt5-47): unsupported; no executable behaviour family
- 2× Metagross (me4-61): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Zeraora (sv10-78): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 4× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 3× Wondrous Patch (me2-94): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 1× Brave Bangle (rsv10pt5-80): unsupported; no executable behaviour family
- 1× Lucky Helmet (sv6-158): unsupported; no executable behaviour family
- 4× Academy at Night (sv6pt5-54): unsupported; no executable behaviour family
- 4× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family
- 3× Boomerang Energy (sv6-166): unsupported; no executable behaviour family

### Crustle — Rahul Reddy

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 3× Dwebble (sv10-11): unsupported; no executable behaviour family
- 3× Crustle (sv10-12): unsupported; no executable behaviour family
- 2× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 2× Eri (sv5-146): unsupported; no executable behaviour family
- 1× Xerosic's Machinations (sv6pt5-64): unsupported; no executable behaviour family
- 1× Bianca's Devotion (sv5-142): unsupported; no executable behaviour family
- 1× Lisia's Appeal (sv8-179): unsupported; no executable behaviour family
- 4× Jumbo Ice Cream (me2-91): unsupported; no executable behaviour family
- 1× Hand Trimmer (sv5-150): unsupported; no executable behaviour family
- 1× Hero's Cape (sv5-152): unsupported; no executable behaviour family
- 1× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 1× Community Center (sv6-146): unsupported; no executable behaviour family
- 1× Festival Grounds (sv6-149): unsupported; no executable behaviour family
- 4× Spiky Energy (sv9-159): unsupported; no executable behaviour family
- 4× Growing Grass Energy (me3-86): unsupported; no executable behaviour family
- 4× Mist Energy (sv5-161): unsupported; no executable behaviour family

### Rocket's Mewtwo — Juho Kallama

- 4× Team Rocket's Spidops (sv10-20): unsupported; no executable behaviour family
- 2× Team Rocket's Mewtwo ex (sv10-81): unsupported; no executable behaviour family
- 2× Team Rocket's Mimikyu (sv10-87): unsupported; no executable behaviour family
- 2× Team Rocket's Articuno (sv10-51): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 2× Bug Catching Set (sv6-143): unsupported; no executable behaviour family
- 2× Lucky Helmet (sv6-158): unsupported; no executable behaviour family
- 1× Maximum Belt (sv5-154): unsupported; no executable behaviour family
- 2× Prism Tower (me4-80): unsupported; no executable behaviour family

### N's Zoroark — Tord Reklev

- 4× N's Zoroark ex (sv9-98): unsupported; no executable behaviour family
- 2× N's Zekrom (me2pt5-155): unsupported; no executable behaviour family
- 1× N's Darmanitan (sv9-27): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Black Belt's Training (sv9-143): unsupported; no executable behaviour family
- 1× Ruffian (sv9-157): unsupported; no executable behaviour family
- 4× Transformation Tome (me4-83): unsupported; no executable behaviour family
- 3× N's PP Up (sv9-153): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 2× N's Castle (sv9-152): unsupported; no executable behaviour family

### Ogerpon Box — Mees Brenninkmeijer

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 3× Meowth ex (me3-62): unsupported; no executable behaviour family
- 2× Latias ex (sv8-76): unsupported; no executable behaviour family
- 2× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 1× Wellspring Mask Ogerpon ex (sv6-64): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Chien-Pao (sv8-56): unsupported; no executable behaviour family
- 1× Teal Mask Ogerpon ex (sv6-25): unsupported; no executable behaviour family
- 1× Koraidon ex (me2pt5-121): unsupported; no executable behaviour family
- 4× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Brock's Scouting (sv9-146): unsupported; no executable behaviour family
- 1× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Hero's Cape (sv5-152): unsupported; no executable behaviour family
- 4× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family
- 2× Prism Energy (me2pt5-216): unsupported; no executable behaviour family

### Hydrapple — Grant Walworth

- 4× Teal Mask Ogerpon ex (sv6-25): unsupported; no executable behaviour family
- 2× Applin (sv6-17): unsupported; no executable behaviour family
- 2× Dipplin (sv6-18): unsupported; no executable behaviour family
- 2× Hydrapple ex (sv7-14): unsupported; no executable behaviour family
- 1× Chikorita (me2pt5-8): unsupported; no executable behaviour family
- 1× Bayleef (me1-9): unsupported; no executable behaviour family
- 2× Meganium (me1-10): partial; no executable behaviour family
- 1× Hoothoot (sv7-114): unsupported; no executable behaviour family
- 1× Noctowl (sv7-115): partial; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Celebi (me1-12): unsupported; no executable behaviour family
- 2× Dawn (me2-87): unsupported; no executable behaviour family
- 1× Briar (sv7-132): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 4× Bug Catching Set (sv6-143): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 3× Forest of Vitality (me1-117): unsupported; no executable behaviour family

### Alakazam Dudunsparce — Cerys Jones

- 4× Abra (me1-54): unsupported; no executable behaviour family
- 4× Kadabra (me1-55): partial; no executable behaviour family
- 3× Alakazam (me1-56): unsupported; no executable behaviour family
- 1× Alakazam (sv6-82): unsupported; no executable behaviour family
- 3× Dunsparce (sv9-120): unsupported; no executable behaviour family
- 2× Dudunsparce (sv5-129): partial; no executable behaviour family
- 1× Dedenne (sv8-87): unsupported; no executable behaviour family
- 1× Elgyem (zsv10pt5-40): unsupported; no executable behaviour family
- 1× Genesect (sv6pt5-40): partial; no executable behaviour family
- 1× Psyduck (me2pt5-39): partial; no executable behaviour family
- 4× Dawn (me2-87): unsupported; no executable behaviour family
- 3× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 1× Eri (sv5-146): unsupported; no executable behaviour family
- 1× Sacred Ash (sv10-168): unsupported; no executable behaviour family
- 1× Enhanced Hammer (sv6-148): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 1× Lucky Helmet (sv6-158): unsupported; no executable behaviour family
- 1× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 4× Nighttime Mine (me2pt5-197): unsupported; no executable behaviour family
- 4× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family
- 1× Enriching Energy (sv8-191): unsupported; no executable behaviour family

### Dragapult Blaziken — Jon Webb

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 2× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Combusken (sv10-41): unsupported; no executable behaviour family
- 2× Blaziken ex (sv9-24): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Chi-Yu (sv6-39): unsupported; no executable behaviour family
- 1× Shaymin (sv10-10): partial; no executable behaviour family
- 2× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Miguel Angel Marin Herrera

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Risky Ruins (me1-127): unsupported; no executable behaviour family
- 1× Jamming Tower (sv6-153): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Abaan Ahmed

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Abra (sv6-80): partial; no executable behaviour family
- 1× Kadabra (me1-55): partial; no executable behaviour family
- 1× Alakazam (me1-56): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Chi-Yu (sv6-39): unsupported; no executable behaviour family
- 2× Crispin (sv7-133): unsupported; no executable behaviour family
- 2× Dawn (me2-87): unsupported; no executable behaviour family
- 1× Xerosic's Machinations (sv6pt5-64): unsupported; no executable behaviour family
- 1× Rosa's Encouragement (me3-84): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 2× Risky Ruins (me1-127): unsupported; no executable behaviour family

### Dragapult Blaziken — Jackson Ford

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 2× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Combusken (sv10-41): unsupported; no executable behaviour family
- 2× Blaziken ex (sv9-24): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 1× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 1× Lillie's Pearl (sv9-151): unsupported; no executable behaviour family
- 1× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult Dusknoir — Natalie Millar

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 2× Duskull (sv8pt5-35): unsupported; no executable behaviour family
- 2× Dusclops (sv8pt5-36): partial; no executable behaviour family
- 1× Dusknoir (sv8pt5-37): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### N's Zoroark — Liam Halliburton

- 4× N's Zoroark ex (sv9-98): unsupported; no executable behaviour family
- 1× Drapion (me3-52): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 1× Purrloin (rsv10pt5-55): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Mega Absol ex (me1-86): unsupported; no executable behaviour family
- 1× N's Zekrom (me2pt5-155): unsupported; no executable behaviour family
- 1× N's Reshiram (sv9-116): unsupported; no executable behaviour family
- 4× Transformation Tome (me4-83): unsupported; no executable behaviour family
- 3× N's PP Up (sv9-153): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 2× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 1× N's Castle (sv9-152): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Leonardo Lattanzi

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 3× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Ogerpon Box — Nicholas Cucinelli

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 3× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Teal Mask Ogerpon ex (sv6-25): unsupported; no executable behaviour family
- 2× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 2× Latias ex (sv8-76): unsupported; no executable behaviour family
- 1× Chien-Pao (sv8-56): unsupported; no executable behaviour family
- 1× Passimian (sv8-111): unsupported; no executable behaviour family
- 1× Raging Bolt ex (sv5-123): unsupported; no executable behaviour family
- 1× Wellspring Mask Ogerpon ex (sv6-64): unsupported; no executable behaviour family
- 4× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 1× Glass Trumpet (sv7-135): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 4× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family

### Dragapult — Paolo Camus

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 2× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Slowking — Isaac Alexander Martinez Mendoza

- 4× Slowpoke (sv7-57): unsupported; no executable behaviour family
- 3× Slowking (sv7-58): unsupported; no executable behaviour family
- 2× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 2× Kyurem (sv6pt5-47): unsupported; no executable behaviour family
- 2× Latias ex (sv8-76): unsupported; no executable behaviour family
- 1× Smoochum (sv8-75): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Metagross (me4-61): unsupported; no executable behaviour family
- 1× Annihilape (sv8-100): unsupported; no executable behaviour family
- 3× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 1× Surfer (sv8-187): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 3× Wondrous Patch (me2-94): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 1× Lucky Helmet (sv6-158): unsupported; no executable behaviour family
- 1× Brave Bangle (rsv10pt5-80): unsupported; no executable behaviour family
- 4× Academy at Night (sv6pt5-54): unsupported; no executable behaviour family
- 4× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family
- 3× Boomerang Energy (sv6-166): unsupported; no executable behaviour family

### Crustle — Hale Obernolte

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 3× Dwebble (sv10-11): unsupported; no executable behaviour family
- 3× Crustle (sv10-12): unsupported; no executable behaviour family
- 1× Psyduck (me2pt5-39): partial; no executable behaviour family
- 3× Eri (sv5-146): unsupported; no executable behaviour family
- 2× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 1× Bianca's Devotion (sv5-142): unsupported; no executable behaviour family
- 1× Xerosic's Machinations (sv6pt5-64): unsupported; no executable behaviour family
- 1× Lisia's Appeal (sv8-179): unsupported; no executable behaviour family
- 4× Jumbo Ice Cream (me2-91): unsupported; no executable behaviour family
- 1× Lumiose Galette (me3-78): unsupported; no executable behaviour family
- 1× Hero's Cape (sv5-152): unsupported; no executable behaviour family
- 1× Lumiose City (me3-77): unsupported; no executable behaviour family
- 4× Spiky Energy (sv9-159): unsupported; no executable behaviour family
- 4× Mist Energy (sv5-161): unsupported; no executable behaviour family
- 4× Growing Grass Energy (me3-86): unsupported; no executable behaviour family

### Dragapult — Daniel Powell

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 2× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 3× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Hydrapple — Ben Dobberstein

- 4× Teal Mask Ogerpon ex (sv6-25): unsupported; no executable behaviour family
- 2× Chikorita (me2pt5-8): unsupported; no executable behaviour family
- 2× Bayleef (me1-9): unsupported; no executable behaviour family
- 2× Meganium (me1-10): partial; no executable behaviour family
- 2× Applin (sv6-17): unsupported; no executable behaviour family
- 2× Dipplin (sv6-18): unsupported; no executable behaviour family
- 2× Hydrapple ex (sv7-14): unsupported; no executable behaviour family
- 2× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Celebi (me1-12): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 1× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 1× Briar (sv7-132): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 4× Bug Catching Set (sv6-143): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 4× Forest of Vitality (me1-117): unsupported; no executable behaviour family

### N's Zoroark — Luke Morsa

- 4× N's Zoroark ex (sv9-98): unsupported; no executable behaviour family
- 2× N's Zekrom (me2pt5-155): unsupported; no executable behaviour family
- 1× N's Reshiram (sv9-116): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 1× Black Belt's Training (sv9-143): unsupported; no executable behaviour family
- 1× Xerosic's Machinations (sv6pt5-64): unsupported; no executable behaviour family
- 3× N's PP Up (sv9-153): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 2× N's Castle (sv9-152): unsupported; no executable behaviour family
- 1× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Jack Moore

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 2× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Caleb Gedemer

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Rabsca (sv5-24): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 2× Dawn (me2-87): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family

### Dragapult — Blake Underhill

- 4× Drakloak (sv6-129): partial; no executable behaviour family
- 3× Dragapult ex (sv6-130): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 4× Crushing Hammer (me3-71): unsupported; no executable behaviour family
- 1× Unfair Stamp (sv6-165): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 2× Team Rocket's Watchtower (sv10-180): unsupported; no executable behaviour family
- 1× Risky Ruins (me1-127): unsupported; no executable behaviour family

### N's Zoroark — Benjamin Martinsen

- 4× N's Zoroark ex (sv9-98): unsupported; no executable behaviour family
- 2× N's Zekrom (me2pt5-155): unsupported; no executable behaviour family
- 1× Yveltal (me1-88): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 2× Black Belt's Training (sv9-143): unsupported; no executable behaviour family
- 1× Ruffian (sv9-157): unsupported; no executable behaviour family
- 4× N's PP Up (sv9-153): unsupported; no executable behaviour family
- 2× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 2× N's Castle (sv9-152): unsupported; no executable behaviour family

### Alakazam Dudunsparce — Diego Cassiraga

- 4× Abra (me1-54): unsupported; no executable behaviour family
- 4× Kadabra (me1-55): partial; no executable behaviour family
- 3× Alakazam (me1-56): unsupported; no executable behaviour family
- 3× Dunsparce (sv9-120): unsupported; no executable behaviour family
- 3× Dudunsparce (sv5-129): partial; no executable behaviour family
- 1× Dedenne (sv8-87): unsupported; no executable behaviour family
- 1× Elgyem (zsv10pt5-40): unsupported; no executable behaviour family
- 1× Genesect (sv6pt5-40): partial; no executable behaviour family
- 1× Shaymin (sv10-10): partial; no executable behaviour family
- 4× Dawn (me2-87): unsupported; no executable behaviour family
- 3× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 2× Enhanced Hammer (sv6-148): unsupported; no executable behaviour family
- 1× Sacred Ash (sv10-168): unsupported; no executable behaviour family
- 1× Lucky Helmet (sv6-158): unsupported; no executable behaviour family
- 1× Handheld Fan (sv6-150): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 4× Nighttime Mine (me2pt5-197): unsupported; no executable behaviour family
- 4× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family
- 1× Enriching Energy (sv8-191): unsupported; no executable behaviour family

### Crustle — Christopher Carillon

- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 3× Dwebble (sv10-11): unsupported; no executable behaviour family
- 3× Crustle (sv10-12): unsupported; no executable behaviour family
- 1× Team Rocket's Kangaskhan ex (me2pt5-162): unsupported; no executable behaviour family
- 1× Team Rocket's Articuno (sv10-51): unsupported; no executable behaviour family
- 1× Psyduck (me2pt5-39): partial; no executable behaviour family
- 2× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 1× Eri (sv5-146): unsupported; no executable behaviour family
- 1× Xerosic's Machinations (sv6pt5-64): unsupported; no executable behaviour family
- 1× Lisia's Appeal (sv8-179): unsupported; no executable behaviour family
- 4× Jumbo Ice Cream (me2-91): unsupported; no executable behaviour family
- 1× Hero's Cape (sv5-152): unsupported; no executable behaviour family
- 1× Lumiose City (me3-77): unsupported; no executable behaviour family
- 4× Growing Grass Energy (me3-86): unsupported; no executable behaviour family
- 4× Mist Energy (sv5-161): unsupported; no executable behaviour family
- 3× Spiky Energy (sv9-159): unsupported; no executable behaviour family

### Mega Lucario — Nicolai Stiborg

- 3× Riolu (sv8pt5-50): unsupported; no executable behaviour family
- 1× Riolu (me1-76): unsupported; no executable behaviour family
- 3× Mega Lucario ex (me1-77): unsupported; no executable behaviour family
- 3× Dunsparce (sv9-120): unsupported; no executable behaviour family
- 2× Dudunsparce (sv5-129): partial; no executable behaviour family
- 1× Dudunsparce ex (sv9-121): unsupported; no executable behaviour family
- 2× Solrock (me1-75): unsupported; no executable behaviour family
- 2× Lunatone (me1-74): partial; no executable behaviour family
- 2× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 4× Fighting Gong (me1-116): unsupported; no executable behaviour family
- 4× Premium Power Pro (me1-124): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Jamming Tower (sv6-153): unsupported; no executable behaviour family
- 4× Rocky Fighting Energy (me3-87): unsupported; no executable behaviour family
- 1× Legacy Energy (sv6-167): unsupported; no executable behaviour family

### Metagross — Drew Cate

- 4× Metang (sv5-114): partial; no executable behaviour family
- 2× Metagross (me4-61): unsupported; no executable behaviour family
- 2× Genesect ex (zsv10pt5-67): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Team Rocket's Articuno (sv10-51): unsupported; no executable behaviour family
- 1× Team Rocket's Kangaskhan ex (me2pt5-162): unsupported; no executable behaviour family
- 1× Shaymin (sv10-10): partial; no executable behaviour family
- 1× Regigigas (sv8pt5-86): unsupported; no executable behaviour family
- 1× Heatran (sv6-123): unsupported; no executable behaviour family
- 2× Brock's Scouting (sv9-146): unsupported; no executable behaviour family
- 2× Energy Recycler (sv10-164): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Precious Trolley (sv8-185): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 1× Brave Bangle (rsv10pt5-80): unsupported; no executable behaviour family

### Mega Greninja — Darien Krys

- 3× Frogadier (me4-21): unsupported; no executable behaviour family
- 2× Greninja ex (sv6-106): unsupported; no executable behaviour family
- 2× Mega Greninja ex (me4-22): unsupported; no executable behaviour family
- 2× Dunsparce (sv9-120): unsupported; no executable behaviour family
- 2× Dudunsparce (sv5-129): partial; no executable behaviour family
- 1× Dudunsparce ex (sv9-121): unsupported; no executable behaviour family
- 1× Meowth ex (me3-62): unsupported; no executable behaviour family
- 1× Budew (me2pt5-16): unsupported; no executable behaviour family
- 1× Psyduck (me2pt5-39): partial; no executable behaviour family
- 3× Hilda (rsv10pt5-84): unsupported; no executable behaviour family
- 1× AZ's Tranquility (me4-76): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 2× Surfing Beach (me1-129): unsupported; no executable behaviour family
- 2× Ignition Energy (rsv10pt5-86): unsupported; no executable behaviour family
- 1× Neo Upper Energy (sv5-162): unsupported; no executable behaviour family

### Joltik Box — Angel Daniel Cardenas Eduardo

- 2× Joltik (sv7-50): unsupported; no executable behaviour family
- 1× Galvantula (sv6pt5-2): unsupported; no executable behaviour family
- 2× Wellspring Mask Ogerpon ex (sv6-64): unsupported; no executable behaviour family
- 2× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 2× Latias ex (sv8-76): unsupported; no executable behaviour family
- 2× Meowth ex (me3-62): unsupported; no executable behaviour family
- 2× Pikachu ex (sv8-57): unsupported; no executable behaviour family
- 1× Iron Leaves ex (sv5-25): unsupported; no executable behaviour family
- 1× Team Rocket's Kangaskhan ex (me2pt5-162): unsupported; no executable behaviour family
- 1× Bloodmoon Ursaluna ex (sv6-141): unsupported; no executable behaviour family
- 1× Team Rocket's Articuno (sv10-51): unsupported; no executable behaviour family
- 4× Crispin (sv7-133): unsupported; no executable behaviour family
- 1× Brock's Scouting (sv9-146): unsupported; no executable behaviour family
- 1× AZ's Tranquility (me4-76): unsupported; no executable behaviour family
- 1× Special Red Card (me4-82): unsupported; no executable behaviour family
- 1× Precious Trolley (sv8-185): unsupported; no executable behaviour family
- 1× Light Ball (me2pt5-191): unsupported; no executable behaviour family
- 2× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family

### Festival Lead — Leighton Catton

- 4× Thwackey (sv6-15): partial; no executable behaviour family
- 1× Rillaboom (sv6-16): unsupported; no executable behaviour family
- 3× Applin (sv6-17): unsupported; no executable behaviour family
- 1× Applin (sv6-126): unsupported; no executable behaviour family
- 4× Dipplin (sv6-18): unsupported; no executable behaviour family
- 1× Petilil (zsv10pt5-6): unsupported; no executable behaviour family
- 1× Lilligant (sv9-7): partial; no executable behaviour family
- 1× Goldeen (sv6-44): unsupported; no executable behaviour family
- 1× Seaking (sv8pt5-21): unsupported; no executable behaviour family
- 1× Shaymin (sv10-10): partial; no executable behaviour family
- 1× Psyduck (me2pt5-39): partial; no executable behaviour family
- 2× Kieran (sv6-154): unsupported; no executable behaviour family
- 1× Lana's Aid (sv6-155): unsupported; no executable behaviour family
- 1× Dawn (me2-87): unsupported; no executable behaviour family
- 1× Drayton (sv8-174): unsupported; no executable behaviour family
- 4× Bug Catching Set (sv6-143): unsupported; no executable behaviour family
- 1× Secret Box (sv6-163): unsupported; no executable behaviour family
- 2× Brave Bangle (rsv10pt5-80): unsupported; no executable behaviour family
- 1× Air Balloon (me2pt5-181): unsupported; no executable behaviour family
- 3× Festival Grounds (sv6-149): unsupported; no executable behaviour family

### Lillie's Clefairy — Zachary Davis

- 4× Meowth ex (me3-62): unsupported; no executable behaviour family
- 4× Mega Kangaskhan ex (me1-104): unsupported; no executable behaviour family
- 4× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 3× Latias ex (sv8-76): unsupported; no executable behaviour family
- 2× Wellspring Mask Ogerpon ex (sv6-64): unsupported; no executable behaviour family
- 1× Moltres (me2-14): unsupported; no executable behaviour family
- 1× Chien-Pao (sv8-56): unsupported; no executable behaviour family
- 1× Passimian (sv8-111): unsupported; no executable behaviour family
- 1× Koraidon ex (me2pt5-121): unsupported; no executable behaviour family
- 3× Crispin (sv7-133): unsupported; no executable behaviour family
- 2× Ciphermaniac's Codebreaking (sv5-145): unsupported; no executable behaviour family
- 4× Dusk Ball (sv8-175): unsupported; no executable behaviour family
- 3× Wondrous Patch (me2-94): unsupported; no executable behaviour family
- 1× Prime Catcher (sv5-157): unsupported; no executable behaviour family
- 2× Lillie's Pearl (sv9-151): unsupported; no executable behaviour family
- 4× Area Zero Underdepths (sv7-131): unsupported; no executable behaviour family
- 1× Telepathic Psychic Energy (me3-88): unsupported; no executable behaviour family

### Rocket's Mewtwo — Jacob Peltier

- 4× Team Rocket's Spidops (sv10-20): unsupported; no executable behaviour family
- 2× Team Rocket's Mewtwo ex (sv10-81): unsupported; no executable behaviour family
- 2× Team Rocket's Articuno (sv10-51): unsupported; no executable behaviour family
- 2× Team Rocket's Mimikyu (sv10-87): unsupported; no executable behaviour family
- 1× Lillie's Clefairy ex (sv9-56): unsupported; no executable behaviour family
- 1× Maximum Belt (sv5-154): unsupported; no executable behaviour family
- 1× Prism Tower (me4-80): unsupported; no executable behaviour family
